


function textLine = foraging_threebuttons_write(E,R,bb)

    
    textLine = sprintf('\n%i\t',...
        bb);
    

end